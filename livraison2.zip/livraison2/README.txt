Projet réalisé par :
	-> 21812350 VOUVOU Brandon
	-> 21911445 KEITA Lansana
	-> 21910271 TOUBAKILA Naslie
	-> 21814023 OGOUWELE Derrick
	
	
	Le fFichier sauvegarde permet de stocker le contenu du jeu lorsqu'on sauvegarde le jeu. 

	
	
	
************************ COMMANDES D'EXECUTION DES FICHIERS *********************************************
	->Jar : java -jar dist/assemblage.jar 
